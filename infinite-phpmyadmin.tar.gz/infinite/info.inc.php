<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Theme information
 *
 * @package    PhpMyAdmin-theme
 * @subpackage Infinite
 */

/**
 * If you have problems or questions about this theme email
 * mikehomme@users.sourceforge.net
 */

/**
 * Icon set used by this theme: http://famfamfam.com/lab/icons/silk/
 */

$theme_name = 'infinite';
$theme_full_version = '1.0';
?>
